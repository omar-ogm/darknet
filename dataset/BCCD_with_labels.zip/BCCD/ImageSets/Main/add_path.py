import os

sets = ['train_original', 'val_original', 'trainval_original', 'test_original']
output_names = ['train', 'val', 'trainval', 'test']

path_to_add="dataset/BCCD/JPEGImages/"

for image_set, output_name in zip(sets, output_names):
    image_ids = open('%s.txt' %image_set).read().strip().split()
    add_path = open('%s.txt' %output_name, 'w')
    for image_id in image_ids:
        add_path.write(path_to_add+image_id+'\n')
    add_path.close()
