import os

sets = ['train', 'val', 'trainval', 'test']

path_to_add="dataset/BBCD/JPEGImages/"

for image_set in sets:
    image_ids = open('%s.txt' %image_set).read().strip().split()
    add_path = open('%s_result.txt' %image_set, 'w')
    for image_id in image_ids:
        add_path.write(path_to_add+image_id+'\n')
    add_path.close()
